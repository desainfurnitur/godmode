---
name: web-api-recon
description: Systematic discovery and exploitation of hidden API surfaces in modern SPAs (React/Next.js/Vue).
---

# Web API Reconnaissance & Exploitation

This skill governs the process of uncovering hidden backend API endpoints when standard directory fuzzing is defeated by catch-all 200 responses or reverse-proxy whitelists.

## 🎯 Trigger Conditions
- Target is a modern SPA/Web App.
- Standard fuzzing (`ffuf`, `gobuster`) returns uniform status codes (e.g., all 200s or all 404s).
- Target has a `robots.txt` disallowing `/api/` or similar.
- Need to identify administrative or privileged endpoints without documentation.

## 🛠️ Execution Workflow

### 1. Surface Analysis & Differential Mapping
When a server returns a catch-all 200, standard HTTP status codes are useless. Use **Differential Analysis** (Response Body Length/Content).
- **Establish Baseline:** Get the length of the main landing page.
- **Differential Fuzzing:** Fuzz endpoints and flag any response whose length differs significantly from the baseline.
- **Pattern Recognition:** Look for plaintext markers (e.g., `"no session"`, `"Unauthorized"`, `{"error":...}`) which indicate a routed endpoint rather than a generic landing page.

### 2. Client-Side Artifact Mining
Modern apps store their route maps in JS bundles.
- **Bundle Extraction:** Download the main JS assets (often in `_next/static/chunks/` or `/assets/`).
- **Pattern Extraction:** Use `grep` with regex to find all strings matching `/api/[a-zA-Z0-9/_.-]+`.
- **Route Mapping:** Correlate extracted paths with observed behavior.
- **Next.js Specifics:** In Next.js App Router, check `_next/static/chunks/app/[route]/page-[hash].js` to find endpoints specific to a given page.

...

## ⚠️ Pitfalls & Lessons
- **False Positive 200s:** Never trust a 200 OK on a modern SPA; always verify content length or body markers.
- **Strict Schema Validation:** Modern backends often use validators (e.g., Zod, Joi). If a NoSQL injection (e.g., `{"password": {"$ne": null}}`) returns a 400 Bad Request, the backend is likely enforcing a strict string type. Pivot to type confusion or logic bypasses.
- **Rate Limiting/Lockouts:** Be aware of account lockout mechanisms on auth endpoints. Use a baseline request to identify lockout thresholds before firing heavy payloads to avoid burning target accounts.
- **Reverse Proxy Whitelists:** Be aware that `/api/` might be blocked at the edge. Look for versioned paths like `/api/v1/` or `/api/v2/`.
  - `X-Admin: true`
- **Parameter Tampering:** Test for IDOR on identified admin paths (e.g., `/api/admin/users/reset-quota?id=1`).

## ⚠️ Pitfalls & Lessons
- **False Positive 200s:** Never trust a 200 OK on a modern SPA; always verify content length or body markers.
- **Reverse Proxy Whitelists:** Be aware that `/api/` might be blocked at the edge. Look for versioned paths like `/api/v1/` or `/api/v2/`.
- **Empty Responses:** An empty response from an admin endpoint (e.g., `/reset-quota`) can be a sign of success or a silent failure. Always verify the outcome via a secondary channel (e.g., checking user balance).

## 🏁 Verification
- **Success:** A response that differs from the landing page and does not return a generic "no session" error.
- **Proof:** Captured JSON response, altered system state, or leaked internal data.
