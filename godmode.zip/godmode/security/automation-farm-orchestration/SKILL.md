---
name: automation-farm-orchestration
description: High-velocity deployment and management of bulk automation bots for API key harvesting and account farming.
tags: [farming, bulk-automation, playwright, key-harvester, alysiscode, 9router]
---

# 🚜 Automation Farm Orchestration

This skill governs the setup, execution, and scaling of \"Automation Farms\"—systems designed to run hundreds of bot instances in parallel to harvest API keys, automate registrations, or perform repetitive tasks across multiple accounts.

## ⚙️ Core Architecture
Automation farms typically follow a layered approach to avoid detection and maximize throughput:
1. **Infrastructure Layer:** VPS (Ubuntu) + Docker/Kubernetes for isolated environments.
2. **Network Layer:** Rotating Residential Proxies + Fingerprint Spoofing (Canvas, WebGL).
3. **Execution Layer:** Headless Browsers (Playwright/Puppeteer) for OAuth/UI tasks + Pure-HTTP (Requests/Httpx) for API-level harvesting.
4. **State Layer:** Incremental state tracking (JSON/SQLite) to ensure resume-capability after crashes or rate-limits.

## 🛠️ Implementation Workflow

### 1. Account & Proxy Setup
- Load accounts from text files (`email:pass` format).
- Load rotating proxies (`host:port:user:pass`).
- Implement a round-robin proxy rotator to distribute requests across IP addresses.

### 2. The Farming Pipeline (State Machine)
Execution must be handled as a state machine to prevent data loss:
`PENDING` $\rightarrow$ `REGISTERING` $\rightarrow$ `REGISTERED` $\rightarrow$ `WAITING` $\rightarrow$ `READY` $\rightarrow$ `INJECTING` $\rightarrow$ `INJECTED`

- **Phase 1 (Login):** Use Playwright (Headless) to handle Google OAuth/PKCE flows. Capture `refresh_token` and `access_token`.
- **Phase 2 (Harvesting):** Use Pure-HTTP requests (RFC 8628 Device Flow) to request device codes, approve them via REST RPC, and poll for the final API key.
- **Phase 3 (Injection):** Automatically register harvested keys into the destination system (e.g., 9Router SQLite DB) to make them immediately usable.

### 3. Anti-Ban & Stealth
- **Pacing:** Insert random delays (15s - 60s) between account processing to avoid IP-based triggers.
- **Error Classification:** 
  - `RETRYABLE`: 429 (Rate Limit), 503 (Server Error), Timeouts. Action: Exponential backoff or defer to a second pass.
  - `PERMANENT`: 403 (Forbidden), Auth Errors, Account Disabled. Action: Move to `failed_accounts.txt` and skip.
- **Session Mirroring:** Synchronize local `accounts.json` with remote state files to allow multi-device orchestration.

## ⚠️ Pitfalls & Fixes
- **Google OAuth Detection:** Use `--disable-blink-features=AutomationControlled` and a real User-Agent to avoid \"This browser is not secure\" errors.
- **Device Flow 429s:** The `approve_device` RPC is often strictly IP-limited. Ensure the specific call uses a dedicated/high-quality proxy, while polling can use rotating ones.
- **SQLite Locking:** When injecting mass keys into a single `.sqlite` file, use a sequential queue or a mutex to prevent `database is locked` errors.

## 📂 Support Files
- `references/alylysiscode-flow.md`: Specifics on the Alysis Code Supabase gateway and device-token polling endpoints.
- `templates/farm_config.yaml`: Boilerplate for proxy pools and target endpoints.
