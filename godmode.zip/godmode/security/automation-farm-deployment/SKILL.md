---
name: automation-farm-deployment
description: Orchestration and deployment of high-velocity automation farms (API harvesting, account mass-registration, and 9Router integration).
---

# Automation Farm Deployment

Prosedur untuk deployment dan manajemen automation farm skala besar untuk panen API key dan registrasi akun massal.

## 🛠️ Workflow Utama

1. **Environment Setup**:
   • Gunakan VPS dengan core tinggi dan RAM besar.
   • Install dependencies (Playwright, Camoufox, dll).
   • Setup Proxy Pool (Residential rotating) untuk bypass rate-limit.

2. **Account Generation**:
   • Gunakan modul registrasi massal (misal: `mass_regist.py`).
   • Integrasikan dengan temporary mail service (misal: `mail_tm.py`).

3. **Harvesting Cycle**:
   • Gunakan headless browser anti-detect (Camoufox) untuk bypass fingerprinting.
   • Implementasikan React Fiber Walk untuk ekstraksi token internal (seperti `createRequestToken`).
   • Gunakan pure-HTTP polling untuk efisiensi setelah token didapat.

4. **Integration & Sync**:
   • Inject hasil panen ke 9Router database (`~/.9router/db/data.sqlite`).
   • Maintain incremental state via `state.json` untuk resume session setelah crash.

## ⚠️ Pitfalls & Fixes

• **Rate Limit 429/503**: Jangan gunakan IP datacenter. Gunakan residential proxies. Implementasikan exponential backoff.
• **Bot Detection**: Gunakan `Camoufox` atau `Playwright` dengan `--disable-blink-features=AutomationControlled`.
• **State Loss**: Selalu simpan progress per akun ke file `.json` atau `.jsonl` agar tidak mengulang dari nol saat restart.
• **9Router Locking**: Pastikan koneksi SQLite ditutup segera setelah write untuk mencegah `database is locked`.

## 🚀 Execution Patterns

```text
┌─ Init: Setup state.json (target count)
│  ├── Login: Headless OAuth / Email Registration
│  ├── Harvest: Fiber Walk -> Device Flow -> API Key
│  └── Inject: SQL Insert to 9Router DB
▼ End: Update accounts.jsonl
```
